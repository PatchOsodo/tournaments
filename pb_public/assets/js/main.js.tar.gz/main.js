/**
 * =============================================================================
 * BASKETBALL TOURNAMENT MANAGER — main.js
 * Version : 3.0.0
 *
 * TABLE OF CONTENTS
 * -----------------
 * 1.  Configuration
 * 2.  Logger
 * 3.  PocketBase Client
 * 4.  UI Helpers
 * 5.  Application State
 * 6.  Format Configuration
 * 7.  Fixture Generation Algorithms
 *       7a. Round Robin
 *       7b. Single Elimination  ← bye auto-advance fix applied here
 *       7c. Group Stage
 * 8.  Database Layer (DB)
 * 9.  App Controller
 *       9a. Initialisation
 *       9b. Home Screen
 *       9c. Setup Screen
 *       9d. Names Screen
 *       9e. Fixture Generation & Persistence
 *       9f. Fixtures Screen / Render Helpers
 *       9g. Score Entry (new + edit)
 * 10. Global Error Handlers
 * 11. Boot
 * =============================================================================
 */

/* =============================================================================
   1. CONFIGURATION
   Change API_BASE_URL when deploying to a remote server.
   Leaving it as window.location.origin means "same host as this page",
   which works perfectly since PocketBase serves both the API and pb_public/.
   ============================================================================= */
const CONFIG = {
  API_BASE_URL : window.location.origin,
  VERSION      : '3.0.0',
};

/* =============================================================================
   2. LOGGER
   Structured logger that writes to both the browser console and the
   in-page debug log panel simultaneously.

   Usage:
     Logger.info('Message', { optional: 'context object' });
     Logger.warn('...');
     Logger.error('...');
     Logger.debug('...');
   ============================================================================= */
const Logger = (() => {
  /** @type {Array<{ts:string, level:string, msg:string, detail:string}>} */
  const entries = [];

  /**
   * Write a single log entry.
   * @param {'DEBUG'|'INFO'|'WARN'|'ERROR'} level
   * @param {string} msg
   * @param {object} [ctx]
   */
  function write(level, msg, ctx) {
    const ts     = new Date().toLocaleTimeString('en-GB', { hour12: false });
    const detail = ctx ? ' ' + JSON.stringify(ctx) : '';
    entries.push({ ts, level, msg, detail });

    // Mirror to browser DevTools console
    const fn = { DEBUG: 'debug', INFO: 'info', WARN: 'warn', ERROR: 'error' }[level] || 'log';
    console[fn](`[${ts}] [${level}] ${msg}`, ctx || '');

    // Append to the in-page log panel (may not exist on all pages)
    const container = document.getElementById('log-entries');
    if (!container) return;
    const row = document.createElement('div');
    row.className = 'log-entry';
    row.innerHTML =
      `<span class="log-time">${ts}</span>` +
      `<span class="log-level-${level}">${level}</span>` +
      `<span class="log-msg">${escHtml(msg)}${escHtml(detail)}</span>`;
    container.appendChild(row);
    container.scrollTop = container.scrollHeight;
  }

  /** Minimal HTML escape to prevent XSS in log messages */
  function escHtml(str) {
    return String(str)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }

  return {
    debug          : (m, c) => write('DEBUG', m, c),
    info           : (m, c) => write('INFO',  m, c),
    warn           : (m, c) => write('WARN',  m, c),
    error          : (m, c) => write('ERROR', m, c),
    all            : ()     => [...entries],
    asText         : ()     => entries.map(e => `[${e.ts}] [${e.level}] ${e.msg}${e.detail}`).join('\n'),
    copyToClipboard: () => {
      navigator.clipboard.writeText(Logger.asText())
        .then(() => Logger.info('Log copied to clipboard'))
        .catch(e  => Logger.error('Clipboard copy failed', { error: e.message }));
    },
    clear: () => {
      entries.length = 0;
      const c = document.getElementById('log-entries');
      if (c) c.innerHTML = '';
      Logger.info('Log cleared by user');
    },
  };
})();

/* =============================================================================
   3. POCKETBASE CLIENT
   Single shared instance used by the entire app.
   ============================================================================= */
// PocketBase is loaded via <script src="assets/js/pocketbase.umd.js">
const pb = new PocketBase(CONFIG.API_BASE_URL);

/* =============================================================================
   4. UI HELPERS
   Pure DOM utility functions. No business logic.
   ============================================================================= */
const UI = {

  /** Show one screen, hide all others */
  showScreen(id) {
    Logger.debug('showScreen', { screen: id });
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    const el = document.getElementById(id);
    if (el) el.classList.add('active');
  },

  /** Display an error banner */
  showError(bannerId, msgId, message) {
    Logger.warn('showError', { banner: bannerId, message });
    const banner = document.getElementById(bannerId);
    const msg    = document.getElementById(msgId);
    if (banner) banner.classList.add('visible');
    if (msg)    msg.textContent = message;
  },

  /** Hide an error banner */
  clearError(bannerId) {
    const el = document.getElementById(bannerId);
    if (el) el.classList.remove('visible');
  },

  /**
   * Show a success banner then auto-dismiss after a delay.
   * @param {string} bannerId
   * @param {string} msgId
   * @param {string} message
   * @param {number} [delay=4000] ms before auto-hide
   */
  showSuccess(bannerId, msgId, message, delay = 4000) {
    Logger.info('showSuccess', { message });
    const banner = document.getElementById(bannerId);
    const msg    = document.getElementById(msgId);
    if (banner) banner.classList.add('visible');
    if (msg)    msg.textContent = message;
    setTimeout(() => { if (banner) banner.classList.remove('visible'); }, delay);
  },

  /** Toggle the debug log panel open/closed */
  toggleLog() {
    const panel = document.getElementById('log-panel');
    const arrow = document.getElementById('log-arrow');
    if (!panel) return;
    const open = panel.classList.toggle('open');
    if (arrow) arrow.textContent = open ? '▼' : '▶';
    Logger.debug('Log panel toggled', { open });
  },

  /** Update the connection status indicator in the header */
  setConnectionStatus(online) {
    const dot   = document.getElementById('conn-dot');
    const label = document.getElementById('conn-label');
    if (dot)   dot.className   = 'conn-dot ' + (online ? 'online' : 'offline');
    if (label) label.textContent = online ? 'Connected' : 'Offline';
    Logger.info('Connection status', { online });
  },

  /** Switch between fixture screen tabs */
  switchTab(idx) {
    Logger.debug('switchTab', { idx });
    document.querySelectorAll('.tab').forEach((t, i) => t.classList.toggle('active', i === idx));
    document.querySelectorAll('.tab-panel').forEach((p, i) => p.classList.toggle('active', i === idx));
  },

  /** Update the tournament status badge text and class */
  setStatusBadge(status) {
    const badge = document.getElementById('tournament-status-badge');
    if (!badge) return;
    badge.textContent = status;
    badge.className   = `status-badge badge-${status}`;
  },

  /**
   * Open the score entry modal for a fixture.
   * @param {object} fixture - PocketBase fixture record (with expand)
   * @param {boolean} isEdit - Whether this is editing an existing result
   */
  openModal(fixture, isEdit = false) {
    Logger.info('openModal', { fixtureId: fixture.id, isEdit });
    State.activeFixture = fixture;
    State.isEditMode    = isEdit;

    const homeName = fixture.expand?.home_team?.name || 'Home';
    const awayName = fixture.expand?.away_team?.name || 'Away';

    document.getElementById('modal-home-name').textContent = homeName;
    document.getElementById('modal-away-name').textContent = awayName;
    document.getElementById('modal-title').textContent     = isEdit ? 'Edit result' : 'Enter match result';

    // Pre-fill scores when editing
    document.getElementById('score-home').value = isEdit ? (fixture.home_score ?? '') : '';
    document.getElementById('score-away').value = isEdit ? (fixture.away_score ?? '') : '';

    // Show edit warning if applicable
    const editNote = document.getElementById('modal-edit-note');
    if (editNote) editNote.classList.toggle('visible', isEdit);

    document.getElementById('modal-error').classList.remove('visible');
    document.getElementById('modal-overlay').classList.add('open');
    document.getElementById('score-home').focus();
  },

  /** Close the score modal. If called from overlay click, only close on backdrop. */
  closeModal(event) {
    if (event && event.target !== document.getElementById('modal-overlay')) return;
    document.getElementById('modal-overlay').classList.remove('open');
    State.activeFixture = null;
    State.isEditMode    = false;
    Logger.debug('Modal closed');
  },
};

/* =============================================================================
   5. APPLICATION STATE
   Central mutable state. Only modified by App.* functions.
   ============================================================================= */
const State = {
  activeTournament : null,   // Current tournament PocketBase record
  activeFixture    : null,   // Fixture open in the score modal
  isEditMode       : false,  // Whether modal is in edit vs new entry mode
  fixtures         : [],     // All fixtures for the active tournament
  teams            : [],     // All teams for the active tournament
  setupData        : {       // Transient data during tournament creation
    teamCount : 8,
    format    : 'elimination',
    name      : '',
    names     : [],
  },
};

/* =============================================================================
   6. FORMAT CONFIGURATION
   ============================================================================= */
const FORMATS = [
  { id: 'round_robin', icon: '⟳', name: 'Round robin',  desc: 'Everyone plays everyone' },
  { id: 'elimination', icon: '⌥', name: 'Elimination',  desc: 'Single bracket, best advance' },
  { id: 'group_stage', icon: '⊞', name: 'Group stage',  desc: 'Groups → knockout' },
];

/**
 * Suggest the most appropriate format for a given number of teams.
 * @param {number} n
 * @returns {string} format id
 */
function suggestFormat(n) {
  if (n <= 5)                return 'round_robin';
  if ([4,8,16].includes(n)) return 'elimination';
  if (n >= 6)               return 'group_stage';
  return 'round_robin';
}

/* =============================================================================
   7. FIXTURE GENERATION ALGORITHMS
   Pure functions — no DB calls, no side effects.
   Return plain JS objects describing rounds and matches.
   ============================================================================= */

/**
 * 7a. ROUND ROBIN — circle rotation method.
 *
 * Every team plays every other team exactly once.
 * Odd team counts get a synthetic BYE team to make pairs work out.
 *
 * @param {string[]} teams
 * @returns {{ type:'round_robin', rounds:Array, totalMatches:number }}
 */
function genRoundRobin(teams) {
  Logger.debug('genRoundRobin', { count: teams.length });
  const list  = teams.length % 2 === 1 ? [...teams, 'BYE'] : [...teams];
  const total = list.length;
  const rounds = [];

  for (let r = 0; r < total - 1; r++) {
    const matches = [];
    for (let i = 0; i < total / 2; i++) {
      const a = list[i], b = list[total - 1 - i];
      if (a !== 'BYE' && b !== 'BYE') {
        matches.push({ a, b, isBye: false });
      }
    }
    if (matches.length) rounds.push({ label: `Round ${r + 1}`, matches });
    // Rotate: keep list[0] fixed, rotate the rest
    list.splice(1, 0, list.pop());
  }

  const totalMatches = rounds.reduce((s, r) => s + r.matches.length, 0);
  Logger.debug('genRoundRobin done', { rounds: rounds.length, totalMatches });
  return { type: 'round_robin', rounds, totalMatches };
}

/**
 * 7b. SINGLE ELIMINATION
 *
 * FIX: Byes are no longer just padding. When a team is paired against BYE
 * in Round 1 they automatically advance to Round 2, so Round 2 already has
 * the correct number of real teams — no ghost TBD slots.
 *
 * Example: 6 teams → pad to 8 → 2 byes → round 1 has 4 matches but only
 * 2 are real games. The 2 bye winners are already placed in round 2.
 * Round 2 (Semis) has exactly 4 teams, 2 matches. ✓
 *
 * @param {string[]} teams
 * @returns {{ type:'elimination', rounds:Array, totalMatches:number }}
 */
function genElimination(teams) {
  Logger.debug('genElimination', { count: teams.length });

  // Pad to the next power of 2
  let size = 1;
  while (size < teams.length) size *= 2;
  const byes = size - teams.length;
  if (byes > 0) Logger.info('Byes added for elimination', { byes, paddedTo: size });

  // Interleave real teams and byes so byes are spread at the end of slots
  // Teams at the top of the seeding get the byes (auto-advance)
  const slots = [...teams, ...Array(byes).fill('BYE')];

  // Build round 1 matches
  let currentRoundTeams = [];
  const round1Matches   = [];

  for (let i = 0; i < slots.length; i += 2) {
    const a = slots[i];
    const b = slots[i + 1];

    if (b === 'BYE') {
      // Team a gets a bye — they auto-advance, don't create a visible match
      currentRoundTeams.push(a);
      Logger.debug('Auto-advance bye', { team: a });
    } else {
      // Real match — winner will be determined later (TBD)
      round1Matches.push({ a, b, isBye: false });
      // Placeholder for the winner advancing
      currentRoundTeams.push('__WINNER__');
    }
  }

  const allRounds = [];

  // Only add round 1 if it has real matches (i.e. not all teams got byes)
  if (round1Matches.length > 0) {
    const r1Label =
      size === 2  ? 'Final' :
      size === 4  ? 'Semifinals' :
      size === 8  ? 'Quarterfinals' :
      `Round of ${size}`;
    allRounds.push({ label: r1Label, matches: round1Matches });
  }

  // Build subsequent rounds from currentRoundTeams
  // currentRoundTeams has actual names (bye winners) or '__WINNER__' placeholders
  while (currentRoundTeams.length > 1) {
    const nextRoundTeams  = [];
    const matches         = [];
    const roundSize       = currentRoundTeams.length;

    for (let i = 0; i < roundSize; i += 2) {
      const a = currentRoundTeams[i];
      const b = currentRoundTeams[i + 1];
      // If both are known (bye auto-advances), show them as known
      // Otherwise mark as TBD
      const displayA = a === '__WINNER__' ? 'TBD' : a;
      const displayB = b === '__WINNER__' ? 'TBD' : b;
      matches.push({ a: displayA, b: displayB, isBye: false });
      nextRoundTeams.push('__WINNER__');
    }

    const label =
      nextRoundTeams.length === 1 ? 'Final' :
      nextRoundTeams.length === 2 ? 'Semifinals' :
      nextRoundTeams.length === 4 ? 'Quarterfinals' :
      `Round of ${nextRoundTeams.length * 2}`;

    // Rename previous round label if needed now that we know final structure
    // The current matches form the NEXT round, so label it based on what comes after
    const thisRoundLabel =
      matches.length === 1 ? 'Final' :
      matches.length === 2 ? 'Semifinals' :
      matches.length === 4 ? 'Quarterfinals' :
      `Round of ${matches.length * 2}`;

    allRounds.push({ label: thisRoundLabel, matches });
    currentRoundTeams = nextRoundTeams;
  }

  // Fix up round labels — re-derive them from final structure
  const totalRounds = allRounds.length;
  allRounds.forEach((r, i) => {
    const remaining = allRounds.length - i;
    if (remaining === 1)      r.label = 'Final';
    else if (remaining === 2) r.label = 'Semifinals';
    else if (remaining === 3) r.label = 'Quarterfinals';
    // else keep as-is
  });

  const totalMatches = allRounds.reduce((s, r) => s + r.matches.length, 0);
  Logger.info('genElimination done', {
    inputTeams    : teams.length,
    paddedTo      : size,
    byes,
    rounds        : allRounds.length,
    totalMatches,
    roundSummary  : allRounds.map(r => `${r.label}: ${r.matches.length} matches`),
  });

  return { type: 'elimination', rounds: allRounds, totalMatches };
}

/**
 * 7c. GROUP STAGE
 *
 * Splits teams into groups, runs round robin within each group,
 * then generates a single elimination knockout from the top 2 per group.
 *
 * @param {string[]} teams
 * @returns {{ type:'group_stage', groupFixtures:Array, knockout:object, totalMatches:number }}
 */
function genGroupStage(teams) {
  Logger.debug('genGroupStage', { count: teams.length });
  const numGroups = teams.length <= 8 ? 2 : teams.length <= 12 ? 3 : 4;
  const groups    = Array.from({ length: numGroups }, () => []);
  teams.forEach((t, i) => groups[i % numGroups].push(t));

  Logger.info('Groups formed', { numGroups, sizes: groups.map(g => g.length) });

  const letters      = 'ABCDEFGH';
  const groupFixtures = groups.map((g, gi) => ({
    name   : `Group ${letters[gi]}`,
    teams  : g,
    rounds : genRoundRobin(g).rounds,
  }));

  // Top 2 from each group advance to knockout
  const advancers = groups.map(g => g.slice(0, 2)).flat();
  Logger.debug('Knockout advancers', { count: advancers.length, advancers });

  const knockout = genElimination(advancers);

  const totalGroupMatches = groupFixtures.reduce(
    (s, g) => s + g.rounds.reduce((rs, r) => rs + r.matches.length, 0), 0
  );
  const totalMatches = totalGroupMatches + knockout.totalMatches;
  Logger.debug('genGroupStage done', { totalGroupMatches, knockoutMatches: knockout.totalMatches, totalMatches });
  return { type: 'group_stage', groupFixtures, knockout, totalMatches, numGroups };
}

/* =============================================================================
   8. DATABASE LAYER
   All PocketBase REST calls are centralised here.
   Callers should wrap in try/catch and handle errors appropriately.
   ============================================================================= */
const DB = {

  /** Verify PocketBase is reachable */
  async healthCheck() {
    try {
      await pb.health.check();
      Logger.info('PocketBase health OK');
      return true;
    } catch (e) {
      Logger.error('PocketBase health failed', { error: e.message });
      return false;
    }
  },

  /** Get all tournaments, newest first */
  async getTournaments() {
    Logger.debug('DB.getTournaments');
    return pb.collection('tournaments').getFullList({ sort: '-created' });
  },

  /** Create a new tournament */
  async createTournament(name, format) {
    Logger.info('DB.createTournament', { name, format });
    return pb.collection('tournaments').create({ name, format, status: 'pending' });
  },

  /** Partial update a tournament */
  async updateTournament(id, data) {
    Logger.debug('DB.updateTournament', { id, ...data });
    return pb.collection('tournaments').update(id, data);
  },

  /** Delete a tournament (cascade deletes teams + fixtures via PocketBase relation settings) */
  async deleteTournament(id) {
    Logger.warn('DB.deleteTournament', { id });
    return pb.collection('tournaments').delete(id);
  },

  /** Create a team linked to a tournament */
  async createTeam(tournamentId, name, seed, groupName) {
    return pb.collection('teams').create({
      tournament : tournamentId,
      name,
      seed       : seed ?? null,
      group_name : groupName ?? null,
    });
  },

  /** Fetch all teams for a tournament */
  async getTeams(tournamentId) {
    Logger.debug('DB.getTeams', { tournamentId });
    return pb.collection('teams').getFullList({
      filter : `tournament = "${tournamentId}"`,
      sort   : 'seed',
    });
  },

  /** Create a single fixture record */
  async createFixture(data) {
    return pb.collection('fixtures').create(data);
  },

  /**
   * Fetch all fixtures for a tournament, expanding team relation fields
   * so team names are available without extra queries.
   */
  async getFixtures(tournamentId) {
    Logger.debug('DB.getFixtures', { tournamentId });
    return pb.collection('fixtures').getFullList({
      filter : `tournament = "${tournamentId}"`,
      sort   : 'round,match_number',
      expand : 'home_team,away_team,winner',
    });
  },

  /**
   * Save or update a match result.
   * Used for both new entries and edits.
   */
  async saveFixtureResult(fixtureId, homeScore, awayScore, winnerId) {
    Logger.info('DB.saveFixtureResult', { fixtureId, homeScore, awayScore, winnerId });
    return pb.collection('fixtures').update(fixtureId, {
      home_score : homeScore,
      away_score : awayScore,
      winner     : winnerId,
      status     : 'completed',
    });
  },

  /**
   * For elimination brackets: after a result is saved, find the next-round
   * fixture and assign the winner into the correct team slot (home or away).
   *
   * Match number mapping: match N in round R feeds into match ceil(N/2) in round R+1.
   * - Odd match numbers → home_team slot
   * - Even match numbers → away_team slot
   *
   * @param {string} tournamentId
   * @param {number} currentRound
   * @param {number} currentMatchNumber
   * @param {string} winnerTeamId
   */
  async advanceWinnerElimination(tournamentId, currentRound, currentMatchNumber, winnerTeamId) {
    const nextRound       = currentRound + 1;
    const nextMatchNumber = Math.ceil(currentMatchNumber / 2);
    Logger.info('DB.advanceWinner', { from: `R${currentRound}M${currentMatchNumber}`, to: `R${nextRound}M${nextMatchNumber}` });

    let nextFixtures;
    try {
      nextFixtures = await pb.collection('fixtures').getFullList({
        filter: `tournament = "${tournamentId}" && round = ${nextRound} && match_number = ${nextMatchNumber}`,
      });
    } catch (e) {
      Logger.warn('No next fixture found — may be the final', { nextRound, nextMatchNumber });
      return;
    }

    if (!nextFixtures.length) {
      Logger.warn('advanceWinner: next fixture missing', { nextRound, nextMatchNumber });
      return;
    }

    const next = nextFixtures[0];
    // Odd match numbers fill home_team, even fill away_team
    const slot = currentMatchNumber % 2 === 1 ? 'home_team' : 'away_team';
    await pb.collection('fixtures').update(next.id, { [slot]: winnerTeamId });
    Logger.info('Winner placed in next fixture', { nextFixtureId: next.id, slot });
  },

  /**
   * When a result is edited in an elimination bracket, the previously
   * advanced winner may no longer be correct. This clears the old winner
   * from the next round fixture so it can be re-populated.
   */
  async clearAdvancedWinner(tournamentId, currentRound, currentMatchNumber) {
    const nextRound       = currentRound + 1;
    const nextMatchNumber = Math.ceil(currentMatchNumber / 2);
    Logger.warn('DB.clearAdvancedWinner', { nextRound, nextMatchNumber });

    try {
      const fixtures = await pb.collection('fixtures').getFullList({
        filter: `tournament = "${tournamentId}" && round = ${nextRound} && match_number = ${nextMatchNumber}`,
      });
      if (!fixtures.length) return;
      const slot = currentMatchNumber % 2 === 1 ? 'home_team' : 'away_team';
      await pb.collection('fixtures').update(fixtures[0].id, { [slot]: null, status: 'scheduled', winner: null, home_score: null, away_score: null });
      Logger.info('Cleared advanced winner from next round', { slot });
    } catch (e) {
      Logger.warn('clearAdvancedWinner: no next fixture found', { e: e.message });
    }
  },
};

/* =============================================================================
   9. APP CONTROLLER
   All user-facing actions are methods on this object.
   ============================================================================= */
const App = {

  /* ── 9a. INITIALISATION ──────────────────────────────────────────────── */

  async init() {
    Logger.info('App.init', { version: CONFIG.VERSION, api: CONFIG.API_BASE_URL });

    // Connection check
    const online = await DB.healthCheck();
    UI.setConnectionStatus(online);
    if (!online) {
      UI.showError('home-error', 'home-error-msg',
        'Cannot reach PocketBase. Ensure it is running (./pocketbase serve).');
    }

    // Wire up format grid and team count input on setup screen
    App._initSetupScreen();

    // Load the tournament list
    await App.loadTournaments();
  },

  /* ── 9b. HOME SCREEN ─────────────────────────────────────────────────── */

  async loadTournaments() {
    Logger.info('loadTournaments');
    UI.clearError('home-error');
    const list = document.getElementById('tournament-list');
    if (!list) return;
    list.innerHTML = '<div class="empty-state"><span class="empty-icon">⏳</span>Loading...</div>';

    try {
      const tournaments = await DB.getTournaments();
      Logger.info('Tournaments loaded', { count: tournaments.length });

      if (!tournaments.length) {
        list.innerHTML = `
          <div class="empty-state">
            <span class="empty-icon">🏆</span>
            No tournaments yet.<br>Create one to get started.
          </div>`;
        return;
      }

      list.innerHTML = tournaments.map(t => `
        <div class="tournament-item">
          <div class="tournament-item-info">
            <h3>${escHtml(t.name)}</h3>
            <p>${t.format.replace(/_/g,' ')} · ${new Date(t.created).toLocaleDateString()}</p>
          </div>
          <div class="tournament-item-actions">
            <span class="status-badge badge-${t.status}">${t.status}</span>
            <button class="btn sm primary" onclick="App.openTournament('${t.id}')">Open</button>
            <a class="btn sm ghost" href="bracket.html?id=${t.id}" target="_blank">Bracket</a>
            <button class="btn sm danger"  onclick="App.deleteTournament('${t.id}','${escHtml(t.name)}')">Delete</button>
          </div>
        </div>`).join('');

    } catch (e) {
      Logger.error('loadTournaments failed', { error: e.message });
      UI.showError('home-error', 'home-error-msg', `Could not load tournaments: ${e.message}`);
      list.innerHTML = '<div class="empty-state"><span class="empty-icon">⚠️</span>Failed to load data.</div>';
    }
  },

  async openTournament(tournamentId) {
    Logger.info('openTournament', { tournamentId });
    try {
      State.activeTournament = await pb.collection('tournaments').getOne(tournamentId);
      State.teams            = await DB.getTeams(tournamentId);
      State.fixtures         = await DB.getFixtures(tournamentId);
      App._renderFixturesScreen();
      UI.showScreen('screen-fixtures');
    } catch (e) {
      Logger.error('openTournament failed', { error: e.message });
      UI.showError('home-error', 'home-error-msg', `Could not open tournament: ${e.message}`);
    }
  },

  async deleteTournament(id, name) {
    if (!confirm(`Delete "${name}"? This cannot be undone.`)) return;
    Logger.warn('deleteTournament confirmed', { id });
    try {
      await DB.deleteTournament(id);
      await App.loadTournaments();
    } catch (e) {
      Logger.error('deleteTournament failed', { error: e.message });
      UI.showError('home-error', 'home-error-msg', `Delete failed: ${e.message}`);
    }
  },

  goToHome() {
    Logger.info('goToHome');
    UI.showScreen('screen-home');
    App.loadTournaments();
  },


  /* ── 9c. SETUP SCREEN ────────────────────────────────────────────────── */

  goToSetup() {
    Logger.info('goToSetup');
    State.setupData = { teamCount: 8, format: 'elimination', name: '', names: [] };
    const tcInput = document.getElementById('team-count');
    const tnInput = document.getElementById('tournament-name');
    if (tcInput) tcInput.value = 8;
    if (tnInput) tnInput.value = '';
    App._renderFormatGrid();
    UI.showScreen('screen-setup');
  },

  _initSetupScreen() {
    App._renderFormatGrid();
    const tcInput = document.getElementById('team-count');
    if (!tcInput) return;
    tcInput.addEventListener('input', function () {
      const n = parseInt(this.value, 10);
      UI.clearError('setup-error');
      this.classList.remove('input-error');
      if (!isNaN(n) && n >= 3 && n <= 32) {
        State.setupData.teamCount = n;
        State.setupData.format    = suggestFormat(n);
        App._renderFormatGrid();
      }
    });
  },

  _renderFormatGrid() {
    const el = document.getElementById('format-grid');
    if (!el) return;
    const n         = State.setupData.teamCount;
    const suggested = suggestFormat(n);
    if (!State.setupData.format) State.setupData.format = suggested;

    el.innerHTML = FORMATS.map(f => {
      const isSug = f.id === suggested;
      const isSel = f.id === State.setupData.format;
      return `<div class="format-card ${isSel ? 'selected' : ''}" onclick="App.selectFormat('${f.id}')">
        <div class="fmt-icon">${f.icon}</div>
        <div class="fmt-name">${f.name} ${isSug ? '<span class="badge-teal">suggested</span>' : ''}</div>
        <div class="fmt-desc">${f.desc}</div>
      </div>`;
    }).join('');

    const tip = document.getElementById('format-suggestion');
    if (tip) {
      const tips = {
        round_robin: `Round robin for ${n} teams — every team plays every other team.`,
        elimination: `Single elimination for ${n} teams — bracket style, best advance.`,
        group_stage: `Group stage for ${n} teams — groups then knockout.`,
      };
      tip.textContent = tips[State.setupData.format] || '';
    }
  },

  selectFormat(id) {
    Logger.info('selectFormat', { id });
    State.setupData.format = id;
    App._renderFormatGrid();
  },

  /* ── 9d. NAMES SCREEN ────────────────────────────────────────────────── */

  goToNames() {
    UI.clearError('setup-error');
    const nameVal = (document.getElementById('tournament-name')?.value || '').trim();
    const raw     = document.getElementById('team-count')?.value.trim();
    const n       = parseInt(raw, 10);

    if (!nameVal) {
      UI.showError('setup-error', 'setup-error-msg', 'Please enter a tournament name.');
      return;
    }
    if (!raw || isNaN(n) || n < 3 || n > 32) {
      UI.showError('setup-error', 'setup-error-msg', 'Enter a number of teams between 3 and 32.');
      document.getElementById('team-count')?.classList.add('input-error');
      Logger.error('Invalid team count on goToNames', { raw });
      return;
    }

    State.setupData.name      = nameVal;
    State.setupData.teamCount = n;
    Logger.info('goToNames', { name: nameVal, teams: n, format: State.setupData.format });

    const grid = document.getElementById('team-inputs');
    if (grid) {
      grid.innerHTML = Array.from({ length: n }, (_, i) => `
        <div class="team-input-wrap">
          <span class="team-num">${i + 1}</span>
          <input type="text" placeholder="Team ${i + 1}" id="tn-${i}"
                 value="${escHtml(State.setupData.names[i] || '')}" maxlength="30" />
        </div>`).join('');
    }

    UI.showScreen('screen-names');
  },

  /* ── 9e. FIXTURE GENERATION & PERSISTENCE ────────────────────────────── */

  async generateFixtures() {
    UI.clearError('names-error');
    Logger.info('generateFixtures triggered');

    // Collect names
    const names = Array.from({ length: State.setupData.teamCount }, (_, i) => {
      const el = document.getElementById(`tn-${i}`);
      return (el?.value.trim()) || `Team ${i + 1}`;
    });
    State.setupData.names = names;

    // Validate: no duplicates
    const seen = new Set();
    for (const name of names) {
      const key = name.toLowerCase();
      if (seen.has(key)) {
        UI.showError('names-error', 'names-error-msg',
          `Duplicate team name: "${name}". All names must be unique.`);
        Logger.error('Duplicate team name', { name });
        return;
      }
      seen.add(key);
    }

    const btn = document.getElementById('btn-generate');
    if (btn) { btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Saving...'; }

    try {
      // 1 — Create tournament
      const tournament = await DB.createTournament(State.setupData.name, State.setupData.format);
      Logger.info('Tournament created', { id: tournament.id });

      // 2 — Create teams and build name→id map
      const teamMap = {};
      const numGroups = State.setupData.format === 'group_stage'
        ? (names.length <= 8 ? 2 : names.length <= 12 ? 3 : 4) : null;

      for (let i = 0; i < names.length; i++) {
        const groupName = numGroups
          ? 'ABCDEFGH'[i % numGroups]
          : null;
        const team = await DB.createTeam(tournament.id, names[i], i + 1, groupName);
        teamMap[names[i]] = team.id;
        Logger.debug('Team created', { name: names[i], id: team.id });
      }

      // 3 — Generate fixture structure (pure)
      let generated;
      if      (State.setupData.format === 'round_robin') generated = genRoundRobin(names);
      else if (State.setupData.format === 'elimination') generated = genElimination(names);
      else                                               generated = genGroupStage(names);

      // 4 — Persist fixtures
      await App._persistFixtures(tournament.id, generated, teamMap);
      Logger.info('All fixtures persisted', { tournamentId: tournament.id });

      // 5 — Mark active
      await DB.updateTournament(tournament.id, { status: 'active' });

      // 6 — Load and display
      State.activeTournament = tournament;
      State.activeTournament.status = 'active';
      State.teams    = await DB.getTeams(tournament.id);
      State.fixtures = await DB.getFixtures(tournament.id);
      App._renderFixturesScreen();
      UI.showScreen('screen-fixtures');
      UI.showSuccess('fixtures-success', 'fixtures-success-msg',
        `"${tournament.name}" created — ${generated.totalMatches} matches generated.`);

    } catch (e) {
      Logger.error('generateFixtures failed', { error: e.message, stack: e.stack });
      UI.showError('names-error', 'names-error-msg', `Save failed: ${e.message}`);
    } finally {
      if (btn) { btn.disabled = false; btn.innerHTML = 'Generate &amp; save →'; }
    }
  },

  /**
   * Persist the generated fixture tree to PocketBase.
   * Handles all three formats by normalising to a flat list of round/match pairs.
   *
   * @param {string} tournamentId
   * @param {object} generated   - Output of genRoundRobin / genElimination / genGroupStage
   * @param {object} teamMap     - { teamName: pocketbaseTeamId }
   */
  async _persistFixtures(tournamentId, generated, teamMap) {
    Logger.info('_persistFixtures', { type: generated.type });
    let roundOffset = 0;

    /**
     * Save a set of rounds to PocketBase.
     * @param {Array}  rounds
     * @param {string} [groupName]
     */
    const saveRounds = async (rounds, groupName) => {
      for (let ri = 0; ri < rounds.length; ri++) {
        const round = rounds[ri];
        for (let mi = 0; mi < round.matches.length; mi++) {
          const m      = round.matches[mi];
          const isBye  = m.a === 'BYE' || m.b === 'BYE';
          const isTBD  = m.a === 'TBD' || m.b === 'TBD';

          await DB.createFixture({
            tournament   : tournamentId,
            round        : roundOffset + ri + 1,
            match_number : mi + 1,
            round_label  : round.label,
            home_team    : (!isBye && !isTBD && m.a && teamMap[m.a]) ? teamMap[m.a] : null,
            away_team    : (!isBye && !isTBD && m.b && teamMap[m.b]) ? teamMap[m.b] : null,
            is_bye       : isBye,
            status       : isBye ? 'completed' : 'scheduled',
            group_name   : groupName || null,
          });
        }
      }
      roundOffset += rounds.length;
    };

    if (generated.type === 'group_stage') {
      for (const group of generated.groupFixtures) {
        await saveRounds(group.rounds, group.name);
      }
      await saveRounds(generated.knockout.rounds, null);
    } else {
      await saveRounds(generated.rounds, null);
    }
  },

  /* ── 9f. FIXTURES SCREEN ─────────────────────────────────────────────── */

  _renderFixturesScreen() {
    const t  = State.activeTournament;
    const fx = State.fixtures;

    Logger.info('renderFixturesScreen', { tournament: t.name, fixtureCount: fx.length });

    document.getElementById('sched-title').textContent = t.name;
    document.getElementById('sched-meta').textContent  =
      `${State.teams.length} teams · ${t.format.replace(/_/g,' ')}`;
    UI.setStatusBadge(t.status);

    const realFx   = fx.filter(f => !f.is_bye);
    const done     = realFx.filter(f => f.status === 'completed').length;
    const rounds   = [...new Set(fx.map(f => f.round))].length;

    document.getElementById('stats-row').innerHTML = `
      <div class="stat-box">
        <div class="stat-val">${State.teams.length}</div>
        <div class="stat-lbl">Teams</div>
      </div>
      <div class="stat-box">
        <div class="stat-val">${done}/${realFx.length}</div>
        <div class="stat-lbl">Played</div>
      </div>
      <div class="stat-box">
        <div class="stat-val">${rounds}</div>
        <div class="stat-lbl">Rounds</div>
      </div>`;

    if (t.format === 'round_robin') {
      document.getElementById('tab-row').innerHTML =
        '<button class="tab active" onclick="UI.switchTab(0)">Schedule</button>';
      document.getElementById('tab-panels').innerHTML =
        `<div class="tab-panel active">${App._renderScheduleList(fx)}</div>`;

    } else if (t.format === 'elimination') {
      document.getElementById('tab-row').innerHTML = `
        <button class="tab active" onclick="UI.switchTab(0)">Schedule</button>
        <button class="tab" onclick="UI.switchTab(1)">Bracket</button>`;
      document.getElementById('tab-panels').innerHTML = `
        <div class="tab-panel active">${App._renderScheduleList(fx)}</div>
        <div class="tab-panel">${App._renderInlineBracket(fx)}</div>`;

    } else {
      const groupFx   = fx.filter(f => f.group_name);
      const knockoutFx = fx.filter(f => !f.group_name);
      document.getElementById('tab-row').innerHTML = `
        <button class="tab active" onclick="UI.switchTab(0)">Groups</button>
        <button class="tab" onclick="UI.switchTab(1)">Knockout</button>`;
      document.getElementById('tab-panels').innerHTML = `
        <div class="tab-panel active">${App._renderGroupSchedule(groupFx)}</div>
        <div class="tab-panel">${App._renderScheduleList(knockoutFx)}</div>`;
    }
  },

  /** Render a list of rounds with match cards, grouped by round_label */
  _renderScheduleList(fixtures) {
    const rounds = {};
    fixtures.filter(f => !f.is_bye).forEach(f => {
      const key = f.round_label || `Round ${f.round}`;
      if (!rounds[key]) rounds[key] = [];
      rounds[key].push(f);
    });

    if (!Object.keys(rounds).length) {
      return '<div class="text-muted" style="padding:1rem 0;">No matches yet.</div>';
    }

    return Object.entries(rounds).map(([label, matches]) =>
      `<div class="round-section">
        <div class="round-label">${label}</div>
        ${matches.map((m, i) => App._matchCard(m, i + 1)).join('')}
      </div>`
    ).join('');
  },

  /** Render group schedule grouped by group_name */
  _renderGroupSchedule(fixtures) {
    const groups = {};
    fixtures.filter(f => !f.is_bye).forEach(f => {
      const key = f.group_name || 'Group';
      if (!groups[key]) groups[key] = [];
      groups[key].push(f);
    });

    return Object.entries(groups).map(([name, matches]) =>
      `<div class="round-section">
        <div class="round-label">${name}</div>
        ${matches.map((m, i) => App._matchCard(m, i + 1)).join('')}
      </div>`
    ).join('');
  },

  /**
   * Render a single match card.
   * Shows score if completed, edit button if completed, enter score if scheduled.
   */
  _matchCard(fixture, num) {
    const homeName  = fixture.expand?.home_team?.name || 'TBD';
    const awayName  = fixture.expand?.away_team?.name || 'TBD';
    const isDone    = fixture.status === 'completed';
    const canEnter  = !isDone && homeName !== 'TBD' && awayName !== 'TBD';
    const wHome     = isDone && fixture.winner === fixture.home_team;
    const wAway     = isDone && fixture.winner === fixture.away_team;

    const scoreHtml = isDone
      ? `<span class="match-score">${fixture.home_score} – ${fixture.away_score}</span>`
      : canEnter
        ? `<span class="match-action">Tap to enter</span>`
        : '';

    const editBtn = isDone
      ? `<button class="btn sm ghost" onclick="App.openEditModal('${fixture.id}')" title="Edit result">✏️</button>`
      : '';

    const clickAttr = canEnter
      ? `onclick="App.openScoreModal('${fixture.id}')"`
      : '';

    return `<div class="match-card ${isDone ? 'completed' : ''} ${canEnter ? 'clickable' : ''}" ${clickAttr}>
      <span class="match-num">M${num}</span>
      <span class="team-a ${homeName === 'TBD' ? 'tbd' : ''} ${wHome ? 'winner-bold' : ''}">${homeName}</span>
      <span class="vs">vs</span>
      <span class="team-b ${awayName === 'TBD' ? 'tbd' : ''} ${wAway ? 'winner-bold' : ''}">${awayName}</span>
      ${scoreHtml}
      ${editBtn}
    </div>`;
  },

  /** Render a compact bracket view (inline on fixtures screen) */
  _renderInlineBracket(fixtures) {
    const rounds = {};
    fixtures.filter(f => !f.is_bye).forEach(f => {
      if (!rounds[f.round]) rounds[f.round] = [];
      rounds[f.round].push(f);
    });

    const cols = Object.entries(rounds).map(([round, matches]) => {
      const label = matches[0]?.round_label || `Round ${round}`;
      const cards = matches.map(m => {
        const hn    = m.expand?.home_team?.name || 'TBD';
        const an    = m.expand?.away_team?.name || 'TBD';
        const isDone= m.status === 'completed';
        const wH    = isDone && m.winner === m.home_team;
        const wA    = isDone && m.winner === m.away_team;
        const click = (!isDone && hn !== 'TBD' && an !== 'TBD')
          ? `onclick="App.openScoreModal('${m.id}')"` : '';

        return `<div class="bc-match ${isDone ? 'done' : ''} ${hn === 'TBD' ? 'tbd-match' : ''} ${(!isDone && hn !== 'TBD') ? 'clickable' : ''}" ${click}>
          <div class="bc-team ${hn === 'TBD' ? 'tbd' : ''} ${wH ? 'winner' : ''}">
            <span class="bc-team-name">${hn}</span>
            ${isDone ? `<span class="bc-score">${m.home_score}</span>` : ''}
          </div>
          <div class="bc-team ${an === 'TBD' ? 'tbd' : ''} ${wA ? 'winner' : ''}">
            <span class="bc-team-name">${an}</span>
            ${isDone ? `<span class="bc-score">${m.away_score}</span>` : ''}
          </div>
        </div>`;
      }).join('');

      return `<div class="bc-round">
        <div class="bc-round-label">${label}</div>
        <div class="bc-matches">${cards}</div>
      </div>`;
    }).join('');

    return `<div class="bracket-canvas-wrap"><div class="bracket-canvas">${cols}</div></div>`;
  },

  /* ── 9g. SCORE ENTRY (new + edit) ────────────────────────────────────── */

  /** Open modal for a new result entry */
  async openScoreModal(fixtureId) {
    Logger.info('openScoreModal', { fixtureId });
    try {
      const fixture = await pb.collection('fixtures').getOne(fixtureId, {
        expand: 'home_team,away_team,winner',
      });
      UI.openModal(fixture, false);
    } catch (e) {
      Logger.error('openScoreModal failed', { error: e.message });
    }
  },

  /** Open modal for editing an existing result */
  async openEditModal(fixtureId) {
    Logger.info('openEditModal', { fixtureId });
    try {
      const fixture = await pb.collection('fixtures').getOne(fixtureId, {
        expand: 'home_team,away_team,winner',
      });
      UI.openModal(fixture, true);
    } catch (e) {
      Logger.error('openEditModal failed', { error: e.message });
    }
  },

  /** Save (new or edited) result from the modal */
  async saveResult() {
    const fixture   = State.activeFixture;
    const isEdit    = State.isEditMode;
    if (!fixture) return;

    const homeScore = parseInt(document.getElementById('score-home').value, 10);
    const awayScore = parseInt(document.getElementById('score-away').value, 10);
    const errEl     = document.getElementById('modal-error');
    errEl.classList.remove('visible');

    // Validate
    if (isNaN(homeScore) || isNaN(awayScore) || homeScore < 0 || awayScore < 0) {
      errEl.textContent = 'Enter valid scores (0 or higher) for both teams.';
      errEl.classList.add('visible');
      Logger.warn('Invalid score input', { homeScore, awayScore });
      return;
    }
    if (homeScore === awayScore) {
      errEl.textContent = 'Scores cannot be equal — there must be a winner in basketball.';
      errEl.classList.add('visible');
      Logger.warn('Draw not allowed');
      return;
    }

    const btn = document.getElementById('btn-save-result');
    if (btn) { btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Saving...'; }

    try {
      const winnerId = homeScore > awayScore ? fixture.home_team : fixture.away_team;
      Logger.info('Saving result', { fixtureId: fixture.id, homeScore, awayScore, winnerId, isEdit });

      // If editing an elimination bracket result, first clear the old advancement
      if (isEdit && State.activeTournament.format === 'elimination') {
        await DB.clearAdvancedWinner(fixture.tournament, fixture.round, fixture.match_number);
      }

      // Save the result
      await DB.saveFixtureResult(fixture.id, homeScore, awayScore, winnerId);

      // Advance winner in elimination bracket
      if (State.activeTournament.format === 'elimination') {
        await DB.advanceWinnerElimination(
          fixture.tournament,
          fixture.round,
          fixture.match_number,
          winnerId
        );
      }

      // Check tournament completion
      const allFx  = await DB.getFixtures(fixture.tournament);
      const allDone = allFx.filter(f => !f.is_bye).every(f => f.status === 'completed');
      const status  = allDone ? 'completed' : 'active';
      await DB.updateTournament(fixture.tournament, { status });

      // Refresh state
      State.activeTournament.status = status;
      State.fixtures                = allFx;
      document.getElementById('modal-overlay').classList.remove('open');
      State.activeFixture = null;
      State.isEditMode    = false;

      App._renderFixturesScreen();
      UI.showSuccess('fixtures-success', 'fixtures-success-msg',
        isEdit ? 'Result updated.' : 'Result saved.');

    } catch (e) {
      Logger.error('saveResult failed', { error: e.message });
      errEl.textContent = `Save failed: ${e.message}`;
      errEl.classList.add('visible');
    } finally {
      if (btn) { btn.disabled = false; btn.innerHTML = 'Save result'; }
    }
  },
};

/* =============================================================================
   HELPERS
   ============================================================================= */

/** Minimal HTML escape utility */
function escHtml(str) {
  return String(str)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}

/* =============================================================================
   10. GLOBAL ERROR HANDLERS
   ============================================================================= */
window.addEventListener('error', e => {
  Logger.error('Uncaught error', { message: e.message, file: e.filename, line: e.lineno });
});

window.addEventListener('unhandledrejection', e => {
  Logger.error('Unhandled promise rejection', { reason: String(e.reason) });
});

/* =============================================================================
   11. BOOT
   ============================================================================= */
document.addEventListener('DOMContentLoaded', () => {
  Logger.info('DOM ready — booting Tournament Manager');
  // Only run App.init on pages that have the home screen
  if (document.getElementById('screen-home')) {
    App.init().catch(e => Logger.error('App.init failed', { error: e.message }));
  }
});
